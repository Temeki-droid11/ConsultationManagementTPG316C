/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : Main page
 */
library;

import 'package:assignment/viewmodels/consultaion_view_model.dart'; // Import ViewModel for managing consultation data.
import 'package:flutter/material.dart'; // Import Flutter for UI rendering.
import 'package:provider/provider.dart'; // Import Provider for state management.
import 'routes/route_manager.dart'; // Import custom route manager for handling app routes.
import 'viewmodels/profile_view_model.dart'; // Import ViewModel for managing profile data.

// Entry point for the Flutter application.
void main() {
  runApp(
    MultiProvider(
      providers: [
        // Register ChangeNotifierProviders for state management.
        ChangeNotifierProvider(
            create: (context) =>
                ConsultaionViewModel()), // Manage consultations.
        ChangeNotifierProvider(
            create: (context) =>
                ProfileViewModel()), // Manage profile information.
      ],
      child: const MyApp(), // Root widget of the application.
    ),
  );
}

// Root widget of the application.
class MyApp extends StatelessWidget {
  const MyApp({super.key}); // Constructor for the MyApp widget.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Hides the "Debug" banner.
      title: 'Consultation Booking', // Sets the application title.
      theme: _buildAppTheme(), // Applies the app-wide custom theme.
      initialRoute: RouteManager.home, // Sets the initial route.
      onGenerateRoute: RouteManager.generateRoute, // Handles route generation.
    );
  }

  // Method to define and build the custom theme for the application.
  ThemeData _buildAppTheme() {
    return ThemeData(
      // Custom color scheme.
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.orange, // Base color for the theme.
        primary: Colors.orange, // Primary color for the app.
        secondary: Colors.orangeAccent, // Accent color for secondary elements.
        surface: Colors.white, // Background color for cards and scaffold.
        onPrimary: Colors.white, // Text color on primary background.
        onSurface: Colors.black, // Text color on white surfaces.
      ),
      // Custom text styles for the application.
      textTheme: const TextTheme(
        displayLarge: TextStyle(
          fontSize: 32, // Large display font size.
          fontWeight: FontWeight.bold, // Bold text.
          color: Colors.black, // Text color.
        ),
        displayMedium: TextStyle(
          fontSize: 24, // Medium display font size.
          fontWeight: FontWeight.w600, // Semi-bold text.
          color: Colors.black, // Text color.
        ),
        bodyLarge:
            TextStyle(fontSize: 16, color: Colors.black), // Body text style.
        bodyMedium: TextStyle(
            fontSize: 14, color: Colors.black), // Smaller body text style.
      ),
      // Custom theme for AppBar.
      appBarTheme: const AppBarTheme(
        centerTitle: false, // Align title to the left.
        elevation: 2, // AppBar shadow depth.
        backgroundColor: Colors.orange, // AppBar background color.
        titleTextStyle: TextStyle(
          fontSize: 20, // Title font size.
          fontWeight: FontWeight.w600, // Semi-bold title text.
          color: Colors.white, // Title text color.
        ),
        iconTheme: IconThemeData(color: Colors.white), // Icon color in AppBar.
      ),
      // Custom theme for the BottomNavigationBar.
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.orange, // Background color.
        selectedItemColor: Colors.white, // Color of the selected item.
        unselectedItemColor: Colors.white70, // Color of unselected items.
      ),
      // Custom theme for ElevatedButtons.
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.orange, // Button background color.
          foregroundColor: Colors.white, // Button text color.
          padding: const EdgeInsets.symmetric(
              horizontal: 24, vertical: 12), // Button padding.
          textStyle: const TextStyle(
              fontWeight: FontWeight.bold), // Text style for buttons.
        ),
      ),
      scaffoldBackgroundColor:
          Colors.white, // Default background color for scaffolds.
      // Custom theme for cards.
      cardTheme: CardTheme(
        color: Colors.white, // Card background color.
        elevation: 2, // Card shadow depth.
        margin: const EdgeInsets.symmetric(vertical: 8), // Card margin.
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8), // Rounded corners for cards.
        ),
      ),
    );
  }
}
