/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : HomeScreen
 */
import 'package:assignment/viewmodels/consultaion_view_model.dart'; // Import ViewModel for consultation data management.
import 'package:assignment/views/add_consultation_screen.dart'; // Import screen for adding consultations.
import 'package:assignment/views/consultation_details_screen.dart'; // Import screen for consultation details.
import 'package:assignment/views/widgets/profile_details_screen.dart'; // Import profile details screen widget.
import 'package:flutter/material.dart'; // Import Flutter for UI rendering.
import 'package:provider/provider.dart'; // Import Provider for state management.

// Main entry point for the Home screen of the application.

// Stateless widget to manage navigation and display either consultations or profile details.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Screens accessible via the bottom navigation bar.
    final List<Widget> screens = [
      const ConsultationListScreen(), // Home screen for consultations.
      const ProfileDetailsScreen(), // Profile details screen.
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
            'Consultation Booking'), // Title displayed in the AppBar.
        actions: [
          // Profile button in the AppBar to navigate to the profile screen.
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () {
              // Navigate to the ProfileDetailsScreen when the button is pressed.
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ProfileDetailsScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: screens[0], // Default body showing the ConsultationListScreen.
      bottomNavigationBar: BottomNavigationBar(
        // Defines items for the bottom navigation bar.
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: 1, // Default selected index for navigation.
        onTap: (index) {
          // Navigate to the selected screen when a navigation item is tapped.
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => screens[index],
            ),
          );
        },
      ),
    );
  }
}

// Stateless widget to display a list of consultations.
class ConsultationListScreen extends StatelessWidget {
  const ConsultationListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0), // Add padding around the content.
        child: Column(
          children: [
            // Header for the Consultation List Screen.
            const Row(
              mainAxisAlignment:
                  MainAxisAlignment.center, // Center align header content.
              children: [
                SizedBox(height: 10), // Add spacing.
                Text(
                  'My Consultation Diary',
                  style: TextStyle(
                    fontSize: 20,
                    //  fontWeight: FontWeight.bold,
                    //  color: Colors.orange,
                  ),
                ),
                Icon(Icons.calendar_today), // Add calendar icon.
              ],
            ),
            const SizedBox(height: 20), // Spacing between header and list.
            Expanded(
              // Displays the list of consultations.
              child: Consumer<ConsultaionViewModel>(
                builder: (context, viewModel, child) {
                  final consultaions =
                      viewModel.consultaions; // Fetch consultations.
                  return ListView.builder(
                    itemCount: consultaions.length, // Number of consultations.
                    itemBuilder: (context, index) {
                      final consultaion = consultaions[index];
                      return ListTile(
                        title: Text(consultaion
                            .description), // Display consultation description.
                        leading: const Icon(
                            Icons.calendar_today), // Icon for the list item.
                        onTap: () {
                          // Navigate to the details screen when tapped.
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ConsultationDetailsScreen(
                                consultation:
                                    consultaion, // Pass the selected consultation.
                              ),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        // Navigates to the AddConsultationScreen when the FAB is pressed.
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddConsultationScreen(),
            ),
          );
        },
        child: const Icon(Icons.add), // Icon displayed on the FAB.
      ),
    );
  }
}
