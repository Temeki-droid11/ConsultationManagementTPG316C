/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : ProfileImage
 */
import 'package:assignment/viewmodels/profile_view_model.dart'; // Import ProfileViewModel for accessing user image and state management.
import 'package:flutter/material.dart'; // Import Flutter for UI rendering.
import 'package:provider/provider.dart'; // Import Provider to manage state efficiently.

// Stateless widget for displaying the user's profile image.
class ProfileImage extends StatelessWidget {
  // Callback function to handle image picking action.
  final VoidCallback onImagePick;

  // Constructor to initialize the ProfileImage widget with the image picker callback.
  const ProfileImage({super.key, required this.onImagePick});

  @override
  Widget build(BuildContext context) {
    // Consumer listens to ProfileViewModel for image updates and rebuilds the widget accordingly.
    return Consumer<ProfileViewModel>(
      builder: (context, profileViewModel, child) {
        return GestureDetector(
          // Executes the provided callback when the user taps on the image.
          onTap: onImagePick,
          child: CircleAvatar(
            radius: 50, // Sets the size of the profile image.
            // Displays the user's image if available; otherwise, uses a default network image.
            backgroundImage: profileViewModel.image != null
                ? FileImage(profileViewModel.image!) // Loads local image file.
                : const NetworkImage(
                        'https://picsum.photos/250?image=9') // Default network image as fallback.
                    as ImageProvider,
            // Shows a camera icon overlay if no image is set.
            child: profileViewModel.image == null
                ? const Icon(
                    Icons.camera_alt,
                    size:
                        50, // Icon size matches the CircleAvatar radius for centering.
                    color: Colors.white, // Icon color for better visibility.
                  )
                : null, // No overlay if image exists.
          ),
        );
      },
    );
  }
}
