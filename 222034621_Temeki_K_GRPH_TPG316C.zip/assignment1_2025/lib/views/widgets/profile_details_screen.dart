/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : ProfileDetailsScreen
 */
import 'dart:io'; // Used to handle file operations, like loading images.

import 'package:assignment/viewmodels/profile_view_model.dart'; // Import ProfileViewModel for state management.
import 'package:assignment/views/widgets/profile_details.dart'; // Widget for displaying profile details.
import 'package:assignment/views/widgets/profile_image.dart'; // Widget for displaying profile image.
import 'package:assignment/views/widgets/update_button.dart'; // Widget for the Update button functionality.
import 'package:flutter/material.dart'; // Import Flutter for UI rendering.
import 'package:image_picker/image_picker.dart'; // For allowing users to pick images from their device.
import 'package:provider/provider.dart'; // For managing state using Provider.

// Stateless widget for displaying the Profile Details Screen.
class ProfileDetailsScreen extends StatelessWidget {
  const ProfileDetailsScreen({super.key}); // Constructor for the screen widget.

  // Method for picking an image from the gallery.
  Future<void> _pickImage(BuildContext context) async {
    final ImagePicker picker = ImagePicker(); // Instance to pick images.
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    // If the user selects an image, update the ProfileViewModel with the selected image.
    if (pickedFile != null) {
      // ignore: use_build_context_synchronously
      Provider.of<ProfileViewModel>(context, listen: false)
          .updateImage(File(pickedFile.path));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile Page'), // Title displayed in the AppBar.
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: LayoutBuilder(
          builder: (context, constraints) {
            // Adapt layout based on screen width.
            if (constraints.maxWidth > 600) {
              // Wide layout for larger screens.
              return Row(
                children: [
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 10),
                        // Profile image widget with image picker functionality.
                        ProfileImage(
                          onImagePick: () => _pickImage(context),
                        ),
                        const SizedBox(height: 10),
                        const ProfileDetails(), // Widget to display profile details.
                      ],
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child:
                          UpdateButton(), // Widget for updating profile details.
                    ),
                  ),
                ],
              );
            } else {
              // Compact layout for smaller screens.
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile image widget with image picker functionality.
                  ProfileImage(
                    onImagePick: () => _pickImage(context),
                  ),
                  const SizedBox(height: 10),
                  const ProfileDetails(), // Widget to display profile details.
                  const SizedBox(height: 50),
                  const UpdateButton(), // Widget for updating profile details.
                ],
              );
            }
          },
        ),
      ),
    );
  }
}
