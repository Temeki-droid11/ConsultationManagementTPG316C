/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : ProfileDetails
 */
import 'package:assignment/viewmodels/profile_view_model.dart'; // Import ProfileViewModel for state management.
import 'package:flutter/material.dart'; // Import Flutter for UI rendering.
import 'package:provider/provider.dart'; // Import Provider to manage state efficiently.

// Stateless widget to display the details of the user's profile.
class ProfileDetails extends StatelessWidget {
  const ProfileDetails({super.key}); // Constructor for the widget.

  @override
  Widget build(BuildContext context) {
    // Using Consumer to listen to ProfileViewModel and rebuild the widget when data changes.
    return Consumer<ProfileViewModel>(
        builder: (context, profileViewModel, child) {
      return Column(
        crossAxisAlignment:
            CrossAxisAlignment.start, // Align content to the left.
        children: [
          // Display the user's name in bold, larger orange text.
          Text(
            profileViewModel.name, // User's name from the ProfileViewModel.
            style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Colors.orange),
          ),
          // Display the user's role in smaller, grey text.
          Text(
            profileViewModel.role, // User's role from the ProfileViewModel.
            style: const TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
          ),
          // Add spacing between role and other details.
          const SizedBox(
            height: 20,
          ),
          // Display the user's email in orange-accented text.
          Text(
            'Email: ${profileViewModel.email}', // User's email from the ProfileViewModel.
            style: const TextStyle(fontSize: 20, color: Colors.orangeAccent),
          ),
          // Display the user's phone number in orange-accented text.
          Text(
            'Phone: ${profileViewModel.phoneNumber}', // User's phone number from the ProfileViewModel.
            style: const TextStyle(fontSize: 20, color: Colors.orangeAccent),
          ),
        ],
      );
    });
  }
}
