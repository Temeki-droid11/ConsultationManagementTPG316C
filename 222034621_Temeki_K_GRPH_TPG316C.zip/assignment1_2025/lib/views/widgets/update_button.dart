/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : UpdateButton
 */
import 'package:assignment/viewmodels/profile_view_model.dart'; // Importing the ProfileViewModel for managing profile updates.
import 'package:flutter/material.dart'; // Importing Flutter for UI rendering.
import 'package:provider/provider.dart'; // Importing Provider for state management.

// Stateless widget for the Update button that allows users to modify profile details.
class UpdateButton extends StatelessWidget {
  const UpdateButton({super.key}); // Constructor for the UpdateButton widget.

  @override
  Widget build(BuildContext context) {
    // Function to display an AlertDialog where users can input new profile information.
    void showUpdateDialog(BuildContext context) {
      // Text editing controllers to manage user input for profile fields.
      final TextEditingController nameController = TextEditingController();
      final TextEditingController roleController = TextEditingController();
      final TextEditingController emailController = TextEditingController();
      final TextEditingController phoneController = TextEditingController();

      // Display the dialog with TextFields for user input.
      showDialog(
        context: context,
        builder: (BuildContext dialogContext) {
          return AlertDialog(
            title: const Text('Update Profile'), // Dialog title.
            content: Column(
              mainAxisSize: MainAxisSize
                  .min, // Ensures the dialog adjusts its size to fit content.
              children: [
                // TextField for Name input.
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name', // Label for the Name field.
                  ),
                ),
                const SizedBox(height: 8), // Spacing between fields.
                // TextField for Role input.
                TextField(
                  controller: roleController,
                  decoration: const InputDecoration(
                    labelText: 'Role', // Label for the Role field.
                  ),
                ),
                const SizedBox(height: 8), // Spacing between fields.
                // TextField for Email input.
                TextField(
                  controller: emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email', // Label for the Email field.
                  ),
                ),
                const SizedBox(height: 8), // Spacing between fields.
                // TextField for Phone Number input.
                TextField(
                  controller: phoneController,
                  decoration: const InputDecoration(
                    labelText:
                        'Phone Number', // Label for the Phone Number field.
                  ),
                ),
              ],
            ),
            actions: [
              // Cancel button to close the dialog without updating details.
              TextButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop(); // Close the dialog.
                },
                child: const Text('Cancel'),
              ),
              // Update button to apply changes to the profile if all fields are valid.
              TextButton(
                onPressed: () {
                  // Validate that all fields are filled.
                  if (nameController.text.isEmpty ||
                      roleController.text.isEmpty ||
                      emailController.text.isEmpty ||
                      phoneController.text.isEmpty) {
                    // Display an error message if any field is empty.
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Please fill in all fields!'),
                        backgroundColor: Colors.red, // Error color.
                      ),
                    );
                  } else {
                    // Update profile details using the ProfileViewModel.
                    Provider.of<ProfileViewModel>(
                      context,
                      listen: false,
                    ).updateName(nameController.text); // Update Name.
                    Provider.of<ProfileViewModel>(
                      context,
                      listen: false,
                    ).updateRole(roleController.text); // Update Role.
                    Provider.of<ProfileViewModel>(
                      context,
                      listen: false,
                    ).updateEmail(emailController.text); // Update Email.
                    Provider.of<ProfileViewModel>(
                      context,
                      listen: false,
                    ).updatePhoneNumber(
                        phoneController.text); // Update Phone Number.

                    Navigator.of(dialogContext)
                        .pop(); // Close the dialog after updating.

                    // Display a success message after the update.
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Profile updated successfully!'),
                        backgroundColor: Colors.green, // Success color.
                      ),
                    );
                  }
                },
                child: const Text(
                  'Update',
                  style: TextStyle(
                      color: Colors.green), // Style for the Update button.
                ),
              ),
            ],
          );
        },
      );
    }

    return ElevatedButton(
      onPressed: () => showUpdateDialog(
          context), // Display the update dialog when the button is pressed.
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(
            horizontal: 32, vertical: 16), // Button padding.
      ),
      child: const Text('Update Details'), // Button text.
    );
  }
}
