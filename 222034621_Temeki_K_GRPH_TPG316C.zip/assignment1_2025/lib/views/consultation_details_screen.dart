/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : ConsultationDetailsScreen
 */
import 'package:assignment/models/consultation.dart'; // Import the Consultation model.
import 'package:assignment/viewmodels/consultaion_view_model.dart'; // Import ViewModel for managing consultation data.
import 'package:flutter/material.dart'; // Import Flutter for UI rendering.
import 'package:provider/provider.dart'; // Import Provider for state management.

// Stateless widget to display the details of a specific consultation.
class ConsultationDetailsScreen extends StatelessWidget {
  // The consultation object to display details for.
  final Consultation consultation;

  // Constructor to initialize the consultation object.
  const ConsultationDetailsScreen({super.key, required this.consultation});

  @override
  Widget build(BuildContext context) {
    // Using Consumer to rebuild the UI when consultation data in ViewModel changes.
    return Consumer<ConsultaionViewModel>(
      builder: (context, viewModel, child) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Consultation Details'), // Screen title.
          ),
          body: Padding(
            padding:
                const EdgeInsets.all(16.0), // Add padding around the content.
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start, // Align content to the left.
              children: [
                // Display the date of the consultation.
                Text(
                  'Date: ${consultation.date.toString().split(' ')[0]}',
                ),
                const SizedBox(height: 10), // Spacing between details.
                // Display the time of the consultation.
                Text(
                  'Time: ${consultation.time}',
                ),
                const SizedBox(height: 10), // Spacing between details.
                // Display the topic of the consultation.
                Text(
                  'Topic: ${consultation.topic}',
                ),
                const SizedBox(height: 10), // Spacing between details.
                // Display the description of the consultation.
                Text(
                  'Description: ${consultation.description}',
                ),
                const SizedBox(height: 20), // Add spacing before buttons.
                // Row containing "Back" and "Delete" buttons.
                Row(
                  mainAxisAlignment:
                      MainAxisAlignment.spaceBetween, // Align buttons evenly.
                  children: [
                    // Button to go back to the previous screen.
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(
                            context); // Navigate back to the previous screen.
                      },
                      child: const Text('Back to Home'),
                    ),
                    // Button to delete the consultation.
                    ElevatedButton(
                      onPressed: () {
                        // Show a confirmation dialog before deleting the consultation.
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: const Text('Delete Consultation'),
                              content: const Text(
                                  'Are you sure you want to delete this consultation?'),
                              actions: [
                                // Cancel button to dismiss the dialog.
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context)
                                        .pop(); // Close the dialog.
                                  },
                                  child: const Text('Cancel'),
                                ),
                                // Confirm button to delete the consultation.
                                TextButton(
                                  onPressed: () {
                                    // Find the consultation index by matching its description and remove it.
                                    viewModel.removeConsultation(
                                      viewModel.consultaions.indexWhere((c) =>
                                          c.description ==
                                          consultation.description),
                                    );

                                    // Close both the dialog and the details screen.
                                    Navigator.of(context).pop();
                                    Navigator.of(context).pop();

                                    // Display a success message after deletion.
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            'Consultation deleted successfully'),
                                      ),
                                    );
                                  },
                                  child: const Text('Delete'),
                                ),
                              ],
                            );
                          },
                        );
                      },
                      child: const Icon(
                          Icons.delete), // Icon for the Delete button.
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
