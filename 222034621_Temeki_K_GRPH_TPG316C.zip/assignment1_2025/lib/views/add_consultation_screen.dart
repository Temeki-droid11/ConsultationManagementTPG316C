/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : AddConsultationScreen
 */
import 'package:assignment/models/consultation.dart'; // Import the Consultation model.
import 'package:assignment/viewmodels/consultaion_view_model.dart'; // Import ViewModel for managing consultations.
import 'package:flutter/material.dart'; // Import Flutter for UI rendering.
import 'package:provider/provider.dart'; // Import Provider for state management.

// Stateless widget for adding consultations.
class AddConsultationScreen extends StatelessWidget {
  // Text editing controllers for managing user input in TextField widgets.
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _topicController = TextEditingController();

  // Constructor for the screen widget.
  AddConsultationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ValueNotifier to manage reactive date and time values.
    final ValueNotifier<DateTime?> selectedDate =
        ValueNotifier<DateTime?>(null);
    final ValueNotifier<TimeOfDay?> selectedTime =
        ValueNotifier<TimeOfDay?>(null);

    // Function to handle date selection.
    void selectDate() async {
      DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(), // Default initial date.
        firstDate: DateTime(2000), // Earliest selectable date.
        lastDate: DateTime(2100), // Latest selectable date.
      );
      if (pickedDate != null) {
        selectedDate.value =
            pickedDate; // Update the ValueNotifier with the selected date.
        _dateController.text = pickedDate
            .toString()
            .split(' ')[0]; // Display selected date in TextField.
      }
    }

    // Function to handle time selection.
    void selectTime() async {
      TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(), // Default initial time.
      );
      if (pickedTime != null) {
        selectedTime.value =
            pickedTime; // Update the ValueNotifier with the selected time.
        _timeController.text =
            // ignore: use_build_context_synchronously
            pickedTime.format(context); // Display selected time in TextField.
      }
    }

    // Function to save a new consultation.
    void saveConsultation() {
      // Validate that all fields are filled.
      if (_dateController.text.isEmpty ||
          _timeController.text.isEmpty ||
          _topicController.text.isEmpty ||
          _descriptionController.text.isEmpty) {
        // Display an error message if any field is empty.
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please fill in all fields'),
          ),
        );
        return;
      }

      // Create a new Consultation object using user input.
      final consultation = Consultation(
        date: DateTime.parse(_dateController.text), // Parse and store the date.
        time: _timeController.text, // Store the time.
        description: _descriptionController.text, // Store the description.
        topic: _topicController.text, // Store the topic.
      );

      // Add the new consultation to the ViewModel and notify listeners.
      context.read<ConsultaionViewModel>().addConsultaion(consultation);

      // Display a success message after saving.
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Consultation added successfully!'),
        ),
      );

      // Clear all TextField inputs after saving.
      _dateController.clear();
      _timeController.clear();
      _topicController.clear();
      _descriptionController.clear();

      // Navigate back to the previous screen.
      Navigator.of(context).pop();
    }

    // Build the UI.
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Consultation'), // Screen title.
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0), // Add padding around content.
        child: ListView(
          children: [
            // Date Input Field with ValueListenableBuilder.
            ValueListenableBuilder<DateTime?>(
              valueListenable: selectedDate,
              builder: (context, date, _) {
                return TextField(
                  controller:
                      _dateController, // Manage user input for the date.
                  decoration: InputDecoration(
                    labelText: 'Date', // Label for the field.
                    suffixIcon: IconButton(
                      icon: const Icon(Icons
                          .calendar_today), // Calendar icon for date selection.
                      onPressed: selectDate, // Trigger date selection dialog.
                    ),
                  ),
                  readOnly: true, // Prevent manual text entry.
                  onTap: selectDate, // Trigger date selection when tapped.
                );
              },
            ),
            const SizedBox(height: 20), // Add spacing between fields.

            // Time Input Field with ValueListenableBuilder.
            ValueListenableBuilder<TimeOfDay?>(
              valueListenable: selectedTime,
              builder: (context, time, _) {
                return TextField(
                  controller:
                      _timeController, // Manage user input for the time.
                  decoration: InputDecoration(
                    labelText: 'Time', // Label for the field.
                    suffixIcon: IconButton(
                      icon: const Icon(
                          Icons.access_time), // Clock icon for time selection.
                      onPressed: selectTime, // Trigger time selection dialog.
                    ),
                  ),
                  readOnly: true, // Prevent manual text entry.
                  onTap: selectTime, // Trigger time selection when tapped.
                );
              },
            ),
            const SizedBox(height: 20), // Add spacing between fields.

            // Topic Input Field.
            TextField(
              controller: _topicController, // Manage user input for the topic.
              decoration: const InputDecoration(
                labelText: 'Topic', // Label for the field.
                hintText: 'e.g. Unit 2 clarity', // Placeholder hint text.
              ),
            ),
            const SizedBox(height: 20), // Add spacing between fields.

            // Description Input Field.
            TextField(
              controller:
                  _descriptionController, // Manage user input for the description.
              decoration: const InputDecoration(
                labelText: 'Description', // Label for the field.
                hintText: 'e.g. State management', // Placeholder hint text.
              ),
            ),
            const SizedBox(height: 50), // Add spacing before the button.

            // Save Button to trigger saving the consultation.
            ElevatedButton(
              onPressed: saveConsultation,
              // Save the consultation when pressed.
              child: const Text('Save'), // Button text.
            ),
          ],
        ),
      ),
    );
  }
}
