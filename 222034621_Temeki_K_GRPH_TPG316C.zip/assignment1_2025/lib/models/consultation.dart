/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : Consultation
 */

// This class represents a Consultation model with its attributes and constructor.
class Consultation {
  // The time of the consultation (e.g., "10:00 AM").
  String time;

  // A short description of the consultation (e.g., "Discuss project updates").
  String description;

  // The topic or focus of the consultation (e.g., "Business Strategy").
  String topic;

  // The date of the consultation (e.g., DateTime object representing a specific day).
  DateTime date;

  // Constructor for the Consultation class. It uses named parameters to initialize the attributes.
  // All parameters are required and must be provided when creating a Consultation object.
  Consultation({
    required this.date, // Required: The date of the consultation.
    required this.time, // Required: The time of the consultation.
    required this.description, // Required: The description of the consultation.
    required this.topic, // Required: The topic of the consultation.
  });
}
