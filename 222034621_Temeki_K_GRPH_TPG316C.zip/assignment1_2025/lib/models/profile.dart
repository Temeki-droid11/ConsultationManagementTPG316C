/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : Profile
 */
import 'dart:io';

// This class represents a Profile model for storing user details.
class Profile {
  // The name of the user (e.g., "Panda Doe").
  String name;

  // The email address of the user (e.g., "@stud.cut.co.za").
  String email;

  // The role or designation of the user (e.g., "Lectuere", "Student").
  String role;

  // The phone number of the user (e.g., "+1234567890").
  String phoneNumber;

  // An optional image file representing the user's profile picture.
  File? image;

  // Constructor for the Profile class to initialize its properties.
  // The name, email, phone number, and role fields are required, while the image is optional.
  Profile({
    required this.name, // Required: The name of the user.
    required this.email, // Required: The email address of the user.
    required this.phoneNumber, // Required: The phone number of the user.
    required this.role, // Required: The role or designation of the user.
    this.image, // Optional: The profile image file.
  });
}
