/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : RouteManager
 */
import 'package:assignment/views/add_consultation_screen.dart';
//import 'package:assignment/views/consultaion_details_screen.dart';
import 'package:assignment/views/home_screen.dart';
import 'package:assignment/views/profile_page_screen.dart';
import 'package:flutter/material.dart';

// This class manages all routes and navigation logic for the application.
class RouteManager {
  // Route name for the home screen.
  static const String home = '/';

  // Route name for the profile screen.
  static const String profile = '/profile';

  // Route name for the add consultation screen.
  static const String addConsultation = '/addConsultation';

  // Route name for the consultation details screen (commented out for now).
  static const String consultationDetails = '/consultationDetails';

  // Method to dynamically generate routes based on their settings.
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case home:
        // Navigate to the HomeScreen.
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case profile:
        // Navigate to the ProfilePageScreen.
        return MaterialPageRoute(builder: (_) => const ProfilePageScreen());
      case addConsultation:
        // Navigate to the AddConsultationScreen.
        return MaterialPageRoute(builder: (_) => AddConsultationScreen());

      default:
        // Handle undefined routes by showing an error message.
        return _message('Page not found');
    }
  }

  // Helper method to create error pages for undefined routes.
  static Route<dynamic> _message(String message) {
    return MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: const Text('Error')),
        body: Center(child: Text(message)),
      ),
    );
  }
}

/* Uncomment and use this logic when integrating the ConsultationDetailsScreen:
case consultationDetails:
  if (settings.arguments is Consultation) {
    final consultation = settings.arguments as Consultation;
    return MaterialPageRoute(
      builder: (_) => ConsultaionDetailsScreen(
        consultation: consultation,
      ),
    );
  }
*/
