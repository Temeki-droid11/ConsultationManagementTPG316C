/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : ConsultaionViewModel
 */
import 'dart:io'; // Used to handle file operations.

import 'package:assignment/models/consultation.dart'; // Import the Consultation model.
import 'package:flutter/material.dart'; // Import Flutter for ChangeNotifier functionality.

// ViewModel class for managing consultations and notifying UI about changes.
class ConsultaionViewModel with ChangeNotifier {
  // Private list storing consultations.
  List<Consultation> _consultations = [];

  // Public getter to expose consultations list.
  List<Consultation> get consultaions => _consultations;

  // File path to save and load consultations.
  final String filePath = 'consultations.txt';

  // Constructor to initialize and load consultations from the file.
  ConsultaionViewModel() {
    _loadConsultationsFromFile();
  }

  // Method to add a consultation to the list.
  void addConsultaion(Consultation consultation) {
    _consultations.add(consultation); // Add the consultation to the list.
    _saveConsultationsToFile(); // Save updated list to the file.
    notifyListeners(); // Notify UI about changes.
  }

  // Method to remove a consultation by index.
  void removeConsultation(int index) {
    // Ensure the index is valid.
    if (index >= 0 && index < _consultations.length) {
      _consultations
          .removeAt(index); // Remove the consultation at the specified index.
      _saveConsultationsToFile(); // Save updated list to the file.
      notifyListeners(); // Notify UI about changes.
    }
  }

  // Method to load consultations from the file.
  void _loadConsultationsFromFile() async {
    try {
      final file = File(filePath); // Reference the file using the file path.
      if (await file.exists()) {
        // Check if the file exists.
        final contents =
            await file.readAsString(); // Read file contents as a string.
        final lines = contents.split('\n'); // Split contents into lines.
        // Parse each line to create a Consultation object.
        _consultations = lines.where((line) => line.isNotEmpty).map((line) {
          final parts = line.split('|'); // Split each line into parts.
          return Consultation(
            date: DateTime.parse(parts[0]), // Parse the date.
            time: parts[1], // Get the time.
            description: parts[2], // Get the description.
            topic: parts[3], // Get the topic.
          );
        }).toList(); // Convert to a list of consultations.
        notifyListeners(); // Notify UI about loaded consultations.
      }
    } catch (e) {
      // Handle file load errors.
      // print('Failed to load consultations: $e');
    }
  }

  // Method to save consultations to the file.
  void _saveConsultationsToFile() async {
    try {
      final file = File(filePath); // Reference the file using the file path.
      // Convert consultations to a string for file storage.
      final content = _consultations.map((consultation) {
        return '${consultation.date.toIso8601String()}|${consultation.time}|${consultation.description}|${consultation.topic}';
      }).join('\n'); // Join consultations as newline-separated values.
      await file.writeAsString(content); // Write the string to the file.
    } catch (e) {
      // Handle file save errors.
      //print('Failed to save consultations: $e');
    }
  }
}
