/*
 * Student Numbers: 222034621, 221019559, 223083143, 223004229, 222074359, 223051502, 223021893
 * Student Names  : Temeki K, Maduna R, Ngwenya OL, Serebolo R, Rampedi MO, Masabala T, Sebolai KL
 * Question       : ProfileViewModel
 */
import 'dart:io'; // For managing file operations (e.g., image handling).

import 'package:assignment/models/profile.dart'; // Import the Profile model.
import 'package:flutter/material.dart'; // Import Flutter for ChangeNotifier functionality.

// ViewModel class for managing user profile and notifying UI about changes.
class ProfileViewModel with ChangeNotifier {
  // Private Profile instance containing the user's details.
  final Profile _profile = Profile(
    name: "Mpho Mbele", // Default name for the profile.
    email: 'mmbele@cut.ac.za', // Default email for the profile.
    phoneNumber: '051 507 4382', // Default phone number for the profile.
    role: 'Student', // Default role for the profile.
  );

  // Getter to access the name from the profile.
  String get name => _profile.name;

  // Getter to access the role from the profile.
  String get role => _profile.role;

  // Getter to access the email from the profile.
  String get email => _profile.email;

  // Getter to access the phone number from the profile.
  String get phoneNumber => _profile.phoneNumber;

  // Getter to access the optional profile image.
  File? get image => _profile.image;

  // Method to update the profile's name.
  void updateName(String newName) {
    _profile.name = newName; // Update the name in the Profile object.
    notifyListeners(); // Notify listeners (e.g., UI) about the update.
  }

  // Method to update the profile's role.
  void updateRole(String newRole) {
    _profile.role = newRole; // Update the role in the Profile object.
    notifyListeners(); // Notify listeners (e.g., UI) about the update.
  }

  // Method to update the profile's email.
  void updateEmail(String newEmail) {
    _profile.email = newEmail; // Update the email in the Profile object.
    notifyListeners(); // Notify listeners (e.g., UI) about the update.
  }

  // Method to update the profile's phone number.
  void updatePhoneNumber(String newPhoneNumber) {
    _profile.phoneNumber =
        newPhoneNumber; // Update the phone number in the Profile object.
    notifyListeners(); // Notify listeners (e.g., UI) about the update.
  }

  // Method to update the profile's image.
  void updateImage(File newImage) {
    _profile.image = newImage; // Update the image in the Profile object.
    notifyListeners(); // Notify listeners (e.g., UI) about the update.
  }
}
